CREATE DATABASE  IF NOT EXISTS `meat_inventory` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `meat_inventory`;
-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: meat_inventory
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `product_id` int NOT NULL AUTO_INCREMENT,
  `meat_name` varchar(100) NOT NULL,
  `price_per_kg` double NOT NULL,
  `weight_stock` double NOT NULL,
  `meat_category` varchar(50) NOT NULL,
  `beef_grade` varchar(50) DEFAULT NULL,
  `marbling_score` int DEFAULT NULL,
  `cut_type` varchar(50) DEFAULT NULL,
  `has_bone` tinyint(1) DEFAULT NULL,
  `part_name` varchar(50) DEFAULT NULL,
  `is_organic` tinyint(1) DEFAULT NULL,
  `show_as_new` tinyint(1) DEFAULT '1',
  `added_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'Tomahawk',1,2,'Beef','Prime',5,NULL,NULL,NULL,NULL,1,'2026-03-05 09:51:55','2026-03-05 09:51:55'),(2,'American Spare Ribs',2,5,'Pork',NULL,NULL,'Ribs',0,NULL,NULL,1,'2026-03-05 09:53:45','2026-03-05 11:27:52'),(4,'Tenderloin',5,4,'Beef','Wagyu',5,NULL,NULL,NULL,NULL,1,'2026-03-09 14:09:03','2026-03-09 14:09:03'),(6,'Wagyu Striploin A4',120,45.5,'Beef','Wagyu',10,NULL,NULL,NULL,NULL,1,'2026-03-10 09:14:57','2026-03-10 09:28:18'),(7,'Choice Tenderloin',35.5,80,'Beef','Choice',6,NULL,NULL,NULL,NULL,0,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(8,'Select Ground Beef',12.99,200,'Beef','Select',3,NULL,NULL,NULL,NULL,0,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(9,'Wagyu Ribeye A4',90,60,'Beef','Wagyu',9,NULL,NULL,NULL,NULL,1,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(10,'Prime Brisket',22.5,110,'Beef','Prime',7,NULL,NULL,NULL,NULL,0,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(11,'Choice Chuck Roast',15.99,90.5,'Beef','Choice',5,NULL,NULL,NULL,NULL,1,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(12,'Select Sirloin',18.99,130,'Beef','Select',4,NULL,NULL,NULL,NULL,0,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(13,'Prime T-Bone',38,75,'Beef','Prime',8,NULL,NULL,NULL,NULL,1,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(14,'Wagyu Tomahawk',150,30,'Beef','Wagyu',9,NULL,NULL,NULL,NULL,1,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(15,'Choice Flank Steak',19.5,85,'Beef','Choice',5,NULL,NULL,NULL,NULL,0,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(16,'Prime Skirt Steak',24.99,65.5,'Beef','Prime',7,NULL,NULL,NULL,NULL,1,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(17,'Select Round Roast',14.5,105,'Beef','Select',3,NULL,NULL,NULL,NULL,0,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(18,'Wagyu Ground Beef',25,150,'Beef','Wagyu',8,NULL,NULL,NULL,NULL,1,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(19,'Prime Porterhouse',42,55,'Beef','Prime',8,NULL,NULL,NULL,NULL,0,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(20,'Choice Short Ribs',28.5,95,'Beef','Choice',7,NULL,NULL,NULL,NULL,1,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(21,'Select Stew Meat',11.99,180,'Beef','Select',3,NULL,NULL,NULL,NULL,0,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(22,'Wagyu Picanha',85,40,'Beef','Wagyu',9,NULL,NULL,NULL,NULL,1,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(23,'Prime Top Sirloin',29.99,115,'Beef','Prime',6,NULL,NULL,NULL,NULL,0,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(24,'Choice Tri-Tip',21,70,'Beef','Choice',6,NULL,NULL,NULL,NULL,1,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(25,'Thick Cut Pork Belly',18.5,120,'Pork',NULL,NULL,'Belly',0,NULL,NULL,1,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(26,'Bone-in Pork Chops',14.99,140.5,'Pork',NULL,NULL,'Chop',1,NULL,NULL,0,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(27,'Boneless Tenderloin',22,90,'Pork',NULL,NULL,'Tenderloin',0,NULL,NULL,1,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(28,'Baby Back Ribs',25.5,110,'Pork',NULL,NULL,'Ribs',1,NULL,NULL,1,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(29,'Spare Ribs',21.99,85,'Pork',NULL,NULL,'Ribs',1,NULL,NULL,0,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(30,'Smoked Pork Belly',24,60,'Pork',NULL,NULL,'Belly',0,NULL,NULL,1,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(31,'Center Cut Pork Chops',16.5,130,'Pork',NULL,NULL,'Chop',1,NULL,NULL,0,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(32,'Pork Shoulder Roast',12.99,160,'Pork',NULL,NULL,'Chop',1,NULL,NULL,1,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(33,'Boneless Pork Chops',15.99,115,'Pork',NULL,NULL,'Chop',0,NULL,NULL,0,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(34,'St. Louis Style Ribs',26,75,'Pork',NULL,NULL,'Ribs',1,NULL,NULL,1,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(35,'Pork Tenderloin Medallions',24.5,50,'Pork',NULL,NULL,'Tenderloin',0,NULL,NULL,0,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(36,'Pork Belly Slices',19.99,95,'Pork',NULL,NULL,'Belly',0,NULL,NULL,1,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(37,'Ground Pork',9.99,200,'Pork',NULL,NULL,'Chop',0,NULL,NULL,0,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(38,'Country Style Ribs',18,80,'Pork',NULL,NULL,'Ribs',1,NULL,NULL,1,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(39,'Pork Loin Roast',14.5,145,'Pork',NULL,NULL,'Chop',0,NULL,NULL,0,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(40,'Thin Cut Pork Chops',13.99,100,'Pork',NULL,NULL,'Chop',1,NULL,NULL,1,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(41,'Pork Belly Blocks',17.5,85,'Pork',NULL,NULL,'Belly',0,NULL,NULL,0,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(42,'Marinated Tenderloin',23.99,65,'Pork',NULL,NULL,'Tenderloin',0,NULL,NULL,1,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(43,'Short Ribs (Pork)',20,55,'Pork',NULL,NULL,'Ribs',1,NULL,NULL,0,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(44,'Thick Bone-in Chops',16.99,105,'Pork',NULL,NULL,'Chop',1,NULL,NULL,1,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(45,'Organic Chicken Breast',14.99,180,'Poultry',NULL,NULL,NULL,NULL,'Breast',1,1,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(46,'Chicken Thighs (Bone-in)',8.99,220,'Poultry',NULL,NULL,NULL,NULL,'Thigh',0,0,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(47,'Whole Roaster Chicken',12.5,150,'Poultry',NULL,NULL,NULL,NULL,'Whole',0,1,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(48,'Organic Chicken Wings',11.99,130,'Poultry',NULL,NULL,NULL,NULL,'Wings',1,1,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(49,'Boneless Skinless Thighs',10.5,190,'Poultry',NULL,NULL,NULL,NULL,'Thigh',0,0,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(50,'Free-Range Whole Chicken',18,85,'Poultry',NULL,NULL,NULL,NULL,'Whole',1,1,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(51,'Split Chicken Breast',11.99,160,'Poultry',NULL,NULL,NULL,NULL,'Breast',0,0,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(52,'Buffalo Style Wings',13.5,95,'Poultry',NULL,NULL,NULL,NULL,'Wings',0,1,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(53,'Organic Boneless Thighs',15,110,'Poultry',NULL,NULL,NULL,NULL,'Thigh',1,1,'2026-03-10 09:14:57','2026-03-11 08:11:26'),(54,'Chicken Drumsticks',6.99,250,'Poultry',NULL,NULL,NULL,NULL,'Thigh',0,0,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(55,'Whole Turkey',25,60,'Poultry',NULL,NULL,NULL,NULL,'Whole',0,1,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(56,'Organic Turkey Breast',22.5,75,'Poultry',NULL,NULL,NULL,NULL,'Breast',1,0,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(57,'Party Chicken Wings',10.99,175,'Poultry',NULL,NULL,NULL,NULL,'Wings',0,1,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(58,'Skin-on Chicken Breast',12.99,140,'Poultry',NULL,NULL,NULL,NULL,'Breast',0,0,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(59,'Organic Chicken Drumsticks',9.5,125,'Poultry',NULL,NULL,NULL,NULL,'Thigh',1,1,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(60,'Cornish Game Hen',16,50,'Poultry',NULL,NULL,NULL,NULL,'Whole',0,1,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(62,'Organic Turkey Thighs',18.5,65,'Poultry',NULL,NULL,NULL,NULL,'Thigh',1,1,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(63,'Chicken Tenders',15.5,160,'Poultry',NULL,NULL,NULL,NULL,'Breast',0,0,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(64,'Premium Whole Duck',35,40,'Poultry',NULL,NULL,NULL,NULL,'Whole',0,1,'2026-03-10 09:14:57','2026-03-10 09:14:57'),(66,'Porterhouse',5,7,'Beef','Wagyu',6,NULL,NULL,NULL,NULL,1,'2026-03-10 09:58:18','2026-03-10 09:58:18'),(67,'Chicken',5,3,'Poultry',NULL,NULL,NULL,NULL,'Breast',0,0,'2026-03-11 09:57:27','2026-03-11 09:57:55'),(68,'Chicken',5,3,'Poultry',NULL,NULL,NULL,NULL,'Breast',0,0,'2026-03-11 10:06:15','2026-03-11 10:06:15');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-13 17:26:46
