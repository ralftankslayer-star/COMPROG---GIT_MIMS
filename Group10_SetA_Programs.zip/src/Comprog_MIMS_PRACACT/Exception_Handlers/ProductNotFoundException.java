package Comprog_MIMS_PRACACT.Exception_Handlers;

public class ProductNotFoundException extends Exception {
    public ProductNotFoundException(String message) {
        super(message);
    }
}
