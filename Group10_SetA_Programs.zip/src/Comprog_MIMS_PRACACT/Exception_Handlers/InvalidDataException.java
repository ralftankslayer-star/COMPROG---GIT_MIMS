package Comprog_MIMS_PRACACT.Exception_Handlers;

public class InvalidDataException extends Exception {
    public InvalidDataException(String message) {
        super(message);
    }
}